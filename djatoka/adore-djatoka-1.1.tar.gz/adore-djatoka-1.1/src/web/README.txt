Dear User,

Accompanying this message is a copy of the latest version of the djatoka viewer.  This a reference implementation illustrating the capabilities of the aDORe djatoka Image Server.  The viewer is largely derived from the work of the SourceForge.net IIPImage project (IIPMooViewer Ajax Javascript Client v1.1). Very few changes to iipmooviewer-1.1.js were necessary to achieve the functionality seen in the demo. 

I encourage you to utilize the IIPMooViewer and to explore the use cases and possible applications of the aDORe djatoka Image Server.  This is simply one implementation. We hope to develop a large community around djatoka and would appreciate source code contributions.

Thanks,
Ryan
rchute at users.sourceforge.net